<?php
 $dbhost="localhost";
 $dbusername="root";
 $dbpassword="";
 $dbname="cris";
 $conn=new mysqli($dbhost,$dbusername,$dbpassword,$dbname);

 ?>